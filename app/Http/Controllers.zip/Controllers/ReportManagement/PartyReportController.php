<?php

namespace App\Http\Controllers\ReportManagement;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PartyReportController extends Controller
{
    //
}
