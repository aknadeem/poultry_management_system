<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <?php echo date('Y');?> &copy; Poultry Management System(PMS)
            </div>

        </div>
    </div>
</footer>